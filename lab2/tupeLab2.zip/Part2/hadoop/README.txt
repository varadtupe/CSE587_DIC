
# input files are present in two separate directories, TwitterData and NewsData

# files for mapper and reducer are present in the lab2 folder


# To run the hadoop jar commands which perform mapreduce, 
# give permission to run "run.sh" file through 
$chmod +x run.sh
# run executable file
$./run.sh


# view output of mapreduce in the path given below
lab2/output/

# files used to generate d3.js wordcloud files are present in visualization
link leads to github