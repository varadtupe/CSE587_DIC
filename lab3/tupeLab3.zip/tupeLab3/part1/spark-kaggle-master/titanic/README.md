## Titanic

This is the code for my entry to the [Titanic Kaggle competition](https://www.kaggle.com/c/titanic).

I wrote a blog post about it: [Exploring spark.ml with the Titanic Kaggle competition](
https://benfradet.github.io/blog/2015/12/16/Exploring-spark.ml-with-the-Titanic-Kaggle-competition).

In [bin](bin) you'll find a submit script which will run everything for you.
You can find the code for the job in [Titanic.scala](
src/main/scala/io/github/benfradet/Titanic.scala).
